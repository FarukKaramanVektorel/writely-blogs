import KategoriEkle from "./component/KategoriEkle";
import Index from "./template/Index";


function App() {
  return (
    <>
    <Index />
    <KategoriEkle />
    </>
  );
}

export default App;
